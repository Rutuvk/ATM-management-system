#include<iostream>
#include<string.h>
#include<ctime>
#include<stdlib.h>
using namespace std;
long long int accountNumber=328287420941234;
int pinNumber=7777;
int balance=0;
string name;
long long int enterAccountNumber;
int enterPinNumber;
int changePin;
int selectedOption;
int d, cnt,x;
int t_changePin;
class login 
{
	public:
		void changePIN();
		void showdata();
		void Deposit();
		void WithdrawCash();
		void showInterface()
		{
		cout<<"\n                                       ********WELCOME TO SBI ATM*********                                     \n";
		 }
};
	class Information:public login
    {
    	public:
    	void getData()
    	{
        cout <<"\nEnter name\n"<<endl;
        cin.ignore();
        getline(cin,name);
        cout << "\nEnter Balance\n"<<endl;
        cin >> balance;
    }
    };
    class basic:public Information
		{
			public:
			void getAccountNumberAndPinNumber()
			{
        cout << "\n              WELCOME!           \n" << endl;
	    cout << "\nPlease enter your account number:\n "<<endl;
		cin >> enterAccountNumber;
		if(enterAccountNumber!= accountNumber)
		{
			cout<<"\nAccount number is invalid:\n";
			exit(0);
		}
		else
		{
		cout<<"\nEnter your pin: \n"<<endl;
		cin>>enterPinNumber;
		if (enterPinNumber!=pinNumber) 
		{
			cout<<"\nInvalid Pin Number! Try again.\n";
			exit(0);
		}
		 else
		  {
			cout << "\n         You have successfully Loged in..\n" << endl;
			 }
			}
		}
		      };
	    inline void login::changePIN()
	    {
	    	cout<<"\nDo you want to change your pin?\n"<<endl;
			int ch,i;
			cout<<"\nEnter your choice:\n"<<endl;
			cout<<"\n1.yes\n"<<endl;
			cout<<"\n2.no\n"<<endl;
			cin>>ch;
			switch(ch)
			{
			case 1:
			if(ch==1)
			{
				 	cout<<"\nEnter your old pin\n"<<endl;
	            cin>>enterPinNumber;
	            if (enterPinNumber!=pinNumber) 
		{
			cout<<"\nInvalid Pin Number! Try again.\n";
			exit(0);
		}     
		else
		{
			
		}
				x = 1;
		while (x != 0)
		{
			x = 0;
			cout << "\nEnter the new 4 digit pin : \n"<<endl;
			cin >>changePin ;
			t_changePin = changePin;
			cnt = 0;
			while (t_changePin > 0)
			{
				d = t_changePin % 10;
				cnt++;
				t_changePin = t_changePin/ 10;
			}
			if (cnt != 4)
			{
				x = 1;
				cout << "\n \t Invalid Pin number.\n";
			}
			else
			{
				x = 0;
			}
		}
				cout<<"\nPIN changed successfully!\n "<<endl;
				cout<<"\nLogin again:\n"<<endl;
	            cout << "\n                 WELCOME!              \n" << endl;
	            cout<<"\nEnter account number:\n"<<endl;
	            cin>>enterAccountNumber;
	            cout<<"\nEnter pin number:\n"<<endl;
	            cin>>enterPinNumber;
	             if (enterAccountNumber!= accountNumber||enterPinNumber!=changePin) 
	             {
			     cout<<"\nInvalid account number or Pin Number! Try again.\n";
			     exit(0);
         	    }
	            else
	            {
		        cout << "\nYou have successfully Loged in..\n" << endl;
				}   
				case 2:
				cout<<"\n";
				break;
			default:
				cout<<"\nEnter correct choice:\n";         
	}
}
}

	   inline void login::showdata()
    {
        cout << "\nName:\n" << name << endl;
        cout << "\nAccount No:\n" << accountNumber << endl;
        cout << "\nBalance:\n" <<balance<< endl;
    }
       inline void login::Deposit()
    {
    	int deposit;
        cout << "\nEnter amount to be Deposited\n";
        cin >> deposit;
	    balance= balance+deposit;
        cout << "\nTotal balance is\n"<<balance<<endl;
    } 
    inline void login::WithdrawCash()
		   {
		   	int CashToWithdraw;
		   	int type;
		   	cout<<"\nEnter the account type:\n"<<endl<<endl;
		   	cout<<"\n1.SAVING"<<endl;
		   	cout<<"\n2.CURRENT"<<endl;
		   	cout<<"\n3.CREDIT\n"<<endl;
		   	cin>>type;
		   	if(type==1||type==2||type==3)
		   	{
		   	cout<<"\nEnter the amount you want to withdraw:\n"<<endl;
		    cin>>CashToWithdraw;
		   	if(CashToWithdraw>balance)
            {
            cout<<"\nYou Don't have enough balance to withdraw cash\n"<<endl;
			cout<<"\nPlease try again later\n";	
		   }		   	
		   else
		   {
		   	if(CashToWithdraw<20001)
		   	{
		    balance=balance-CashToWithdraw;
		    cout<<"\nThe remaining balance is\n"<<endl;
		    cout<<balance;
		}
		else
		{
			cout<<"\nThe maximum limit to withdraw amount is 20000:\n"<<endl;
		}
		   }
		   }
		   else
		   {
		   	cout<<"\nEnter valid choice:\n"<<endl;
		   }
	}
	int main()
	{
	time_t tmNow = time(0);
    char *dt = ctime(&tmNow);
    cout<<"\nCurrent Date/Time: \n"<<dt;
    cout<<endl;
        basic b;
        b.showInterface();
		b.getData();
		b.getAccountNumberAndPinNumber();
		 int choice;
    while (1) 
	{
        cout << "\n";
        cout << "\nEnter Your Choice\n"<<endl;
        cout<<"\n1.Change pin\n"<<endl;
        cout << "\n2. Balance Enquiry\n"<<endl;
        cout << "\n3. Deposit Money\n"<<endl;
        cout << "\n4. Withdraw Money\n"<<endl;
        cout << "\n5.Exit"<<endl;
        cin >> choice;
        switch (choice) {
        case 1:
        	system("cls");
            b.changePIN();
            break;
        case 2:
        	system("cls");
            b.showdata();
            break;
        case 3:
        	system("cls");
            b.Deposit();
            break;
        case 4:
        	system("cls");
            b.WithdrawCash();
            break;
        case 5:
            exit(1);
            break;
        default:
            cout << "\nInvalid choice\n";
        }
    }
	}
